function genImgGrid(){
	var grid = document.getElementById('imgGrid');
	var imgs = ['clown.jpg','douchenapoleon.jpg','egyptwars.jpg','for-dummies.jpg','frames.jpg','guitars.jpg','toys.jpg','water.jpg','xray.jpg']; //Number of images
	var div;
	
	for(i=0;i<imgs.length;i++){
		div=document.createElement('div');
		div.style.background='url(../ZedMedia/img/'+imgs[i]+') center center no-repeat';
		div.style.backgroundSize='cover';
		div.className='grid';
		div.onclick=function(){show(this.style.backgroundImage.replace('url("','').replace('")',''))};
		grid.appendChild(div);
	}
}

function togVis(id) {
       var e = document.getElementById(id);
       if(e.style.visibility == 'visible')
          e.style.visibility = 'hidden';
       else
          e.style.visibility = 'visible';
}
function show(img){
	document.getElementById('dImg').src=img;
	togVis("expandedImg");
}