var cPage = 0;
function highlight(i){
	//Remove previous
	var prev = document.getElementById('highlighted');
	prev.id='';

	//Highlight current
	var now = document.getElementById('mNav').getElementsByTagName('a');
	now[i].id='highlighted';

	//Show page
	/*
	var pages
	pages[0]=document.getElementById('cover');
	pages[1]=document.getElementById('photography');
	pages[2]=document.getElementById('photoshop');
	pages[3]=document.getElementById('animation');
	console.log("hello");
	*/
	zmPageChange(i);
}
function zmPageChange(i){
	var frame=document.getElementById('zedMedia');
	var pages=['cover','photoshop'];
	frame.src = "ZedMedia/"+pages[i]+".html";
}