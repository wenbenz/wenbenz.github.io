

function showContact(){
	var cInfo = document.getElementById('contactInfo');
	var cInfoDetail = cInfo.getElementsByTagName('li');
	cInfoDetail[0].innerHTML = 'Phone: (306) '+'737-'+'2773';
	cInfoDetail[1].innerHTML = 'Email: ben'+'&#64;'+'wenbinzhao.com';
	cInfoDetail[0].style.visibility = 'visible';
	cInfoDetail[1].style.visibility = 'visible';
	document.getElementById('show').style.display = 'none';
}