/**
 * Generates Navigation Bar
 */

function makeAll(){
	makeNavBar();
}

function makeNavBar(){
	var navbar = document.getElementById("navbar");

	// Add FA fonts for menu bar
	var head = document.getElementsByTagName('head');
	head[0].innerHTML += '<link rel="stylesheet" href="CSS/font-awesome.min.css">';

	// Navbar Items
	var text = ["Home","About","Media","Contact"];

	// NavHead
	var navHead = document.createElement("div");
	navHead.id="navHead";
	navHead.innerHTML='<img id="navLogo" src="./IMG/splash.png"/><i id="navMenu" onclick="toggleNav()" class="fa fa-bars" aria-hidden="true"></i>';
	navbar.appendChild(navHead);

	//Creates Navbar Items
	var navList = document.createElement('ul');
	for(i=0; i<text.length; i++){
		var a = document.createElement('a');
		var li = document.createElement('li');
		a.setAttribute('href',text[i]+'.html');
		if(i==0)
			a.href='index.html';
		li.innerHTML=text[i];
		li.className='navItem'
		a.appendChild(li);
		navList.appendChild(a);
	}

	//Adds items to NavBar
	navbar.appendChild(navList);
}


function toggleNav(){
	var navList = document.getElementById("navbar").querySelector('ul');
	if(navList.style.display==='none'||navList.style.display=='')
		navList.style.display = 'block';
	else
		navList.style.display = 'none';
}