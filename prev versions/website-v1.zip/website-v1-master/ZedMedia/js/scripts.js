function togVis(id) {
       var e = document.getElementById(id);
       if(e.style.visibility == 'visible')
          e.style.visibility = 'hidden';
       else
          e.style.visibility = 'visible';
}
function show(img,title){
	document.getElementById('dImg').src='./img/'+img;
	document.getElementById('dHead').innerHTML=title;
	togVis('displayBox');
}